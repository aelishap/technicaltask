import React from 'react';
import './App.css';

  


function App() {
  return (
   <>
   
     <h1>sign in</h1>

     <form>
     
      Email: <input type="text" name="email" ></input><br />
      password: <input type="password" name="password" ></input><br />
      <button></button>
     </form>
    
   </>
  );
}

export default App;
