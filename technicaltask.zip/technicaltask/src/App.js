import React from 'react';
import './App.css';

  


function App() {
  return (
   <>
    <div className="head">
     <h1>Create Account</h1>
     <p id="para">Already have an Account
     <a href=" " target="_self">SIGN IN</a></p>
     </div>
     <div className="form1" >
     <form>
      Firstname: <input type="text" name="fname"></input><br />
      Lastname: <input type="text" name="lname" ></input><br />
      Email: <input type="text" name="email" ></input><br />
      password: <input type="password" name="password" ></input><br />
      Repeat password: <input type="password" name="repeat pass" ></input><br />
      <button>submit</button>
     </form>
     </div>
   </>
  );
}

export default App;
